# WeCare Medical Center — Simplified Live Security MVP

## Changes
- Doctor accounts are no longer permanently restricted.
- Existing active restrictions are cleared whenever the server starts.
- Bulk export remains blocked and audited, but the doctor can continue using the demo.
- Live security popups are delivered to both administrator and doctor through Socket.IO.
- Admin-to-doctor messages appear as live doctor popups.
- Policy wording and the policy card section were removed/simplified.
- User-facing timestamps are displayed in Asia/Kolkata time.
- Default port is 3000.

## Run
```cmd
npm install
node server.js
```
Open http://localhost:3000
